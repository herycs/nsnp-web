import React from 'react'
import './index.scss'

function Share() {
        return (
                <div>

                        <div className="header-class">
                                test
                        </div>

                </div>
        )
}

export default Share
