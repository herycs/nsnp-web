export const CHANGE_HOME_DATA = 'home/change_home_data';
export const ADD_HOME_LIST = 'home/add_home_list';
export const TOGGLE_SCROLL_SHOW = 'home/toggle_scroll_show';
export const TOGGLE_WRITE_COMMENT_SHOW = 'home/toggle_write_comment_show';
