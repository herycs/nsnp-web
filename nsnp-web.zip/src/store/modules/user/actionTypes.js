export const CHANGE_USER_DATA = 'user/change_user_data';
export const GET_USER_DATA = 'user/get_user_data';
