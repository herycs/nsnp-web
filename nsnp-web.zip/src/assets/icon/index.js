import { Icon } from "zarm";

export const TabIcon = Icon.createFromIconfont(
  "//at.alicdn.com/t/font_2497930_2qwgx7wgvi5.js"
);